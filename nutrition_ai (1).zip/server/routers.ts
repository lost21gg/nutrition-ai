import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import type { User } from "../drizzle/schema";
import { invokeLLM } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  profile: router({
    get: protectedProcedure.query(({ ctx }) =>
      db.getUserProfile(ctx.user.id)
    ),
    update: protectedProcedure
      .input(z.object({
        weight: z.number().optional(),
        height: z.number().optional(),
        age: z.number().optional(),
        gender: z.enum(["male", "female", "other"]).optional(),
        objective: z.enum(["lose", "maintain", "gain"]).optional(),
        dietType: z.enum(["normal", "vegan", "vegetarian", "lowcarb", "keto", "highprotein"]).optional(),
        dailyCalorieGoal: z.number().optional(),
        profilePhoto: z.string().optional(),
        allergies: z.string().optional(),
        preferences: z.string().optional(),
      }))
      .mutation(({ ctx, input }) =>
        db.upsertUserProfile(ctx.user.id, input)
      ),
  }),

  foods: router({
    search: publicProcedure
      .input(z.object({ query: z.string(), limit: z.number().default(20) }))
      .query(({ input }) =>
        db.searchFoods(input.query, input.limit)
      ),
    getAll: publicProcedure
      .input(z.object({ limit: z.number().default(100) }))
      .query(({ input }) =>
        db.getAllFoods(input.limit)
      ),
    getById: publicProcedure
      .input(z.number())
      .query(({ input }) =>
        db.getFoodById(input)
      ),
  }),

  meals: router({
    getForDay: protectedProcedure
      .input(z.object({ date: z.string() }))
      .query(({ ctx, input }) =>
        db.getMealsForDay(ctx.user.id, input.date)
      ),
    create: protectedProcedure
      .input(z.object({
        mealType: z.enum(["breakfast", "lunch", "dinner", "snack", "other"]),
        date: z.string(),
        notes: z.string().optional(),
        photoUrl: z.string().optional(),
        totalCalories: z.number().optional(),
        totalProtein: z.number().optional(),
        totalCarbs: z.number().optional(),
        totalFat: z.number().optional(),
      }))
      .mutation(({ ctx, input }) =>
        db.createMeal({
          userId: ctx.user.id,
          mealType: input.mealType,
          date: input.date,
          notes: input.notes,
          photoUrl: undefined, // Don't store base64 image
          totalCalories: input.totalCalories || 0,
          totalProtein: input.totalProtein || 0,
          totalCarbs: input.totalCarbs || 0,
          totalFat: input.totalFat || 0,
        })
      ),
  }),

  exercises: router({
    getAll: publicProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(({ input }) =>
        db.getExercises(input.limit)
      ),
    getForDay: protectedProcedure
      .input(z.object({ date: z.string() }))
      .query(({ ctx, input }) =>
        db.getUserExercisesForDay(ctx.user.id, input.date)
      ),
    add: protectedProcedure
      .input(z.object({
        exerciseId: z.number(),
        date: z.string(),
        duration: z.number(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Get exercise details to calculate calories burned
        const exercise = await db.getExerciseById(input.exerciseId);
        const caloriesBurned = exercise ? (exercise.caloriesBurnedPerMinute || 0) * input.duration : 0;
        
        return db.addUserExercise({
          userId: ctx.user.id,
          ...input,
          caloriesBurned,
        });
      }),
  }),

  weight: router({
    getHistory: protectedProcedure
      .input(z.object({ days: z.number().default(30) }))
      .query(({ ctx, input }) =>
        db.getWeightHistory(ctx.user.id, input.days)
      ),
    add: protectedProcedure
      .input(z.object({ weight: z.number(), date: z.string() }))
      .mutation(({ ctx, input }) => {
        const date = new Date(input.date);
        return db.addWeightRecord(ctx.user.id, input.weight, date);
      }),
  }),

  ai: router({
    analyzeMeal: protectedProcedure
      .input(z.object({ photoUrl: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "You are a nutrition expert AI. Analyze the food in the image and provide detailed nutritional information in JSON format with fields: foods (array of detected foods), totalCalories, totalProtein, totalCarbs, totalFat, suggestions (array of improvement suggestions).",
            },
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: "Please analyze this meal image and provide nutritional information.",
                },
                {
                  type: "image_url",
                  image_url: {
                    url: input.photoUrl,
                  },
                },
              ],
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "meal_analysis",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  foods: {
                    type: "array",
                    items: { type: "string" },
                  },
                  totalCalories: { type: "number" },
                  totalProtein: { type: "number" },
                  totalCarbs: { type: "number" },
                  totalFat: { type: "number" },
                  suggestions: {
                    type: "array",
                    items: { type: "string" },
                  },
                },
                required: ["foods", "totalCalories", "totalProtein", "totalCarbs", "totalFat", "suggestions"],
              },
            },
          },
        });
        const content = response.choices[0].message.content;
        return JSON.parse(typeof content === 'string' ? content : "{}");
      }),

    chat: protectedProcedure
      .input(z.object({
        messages: z.array(z.object({
          role: z.enum(["user", "assistant", "system"]),
          content: z.string(),
        })),
      }))
      .mutation(async ({ ctx, input }) => {
        // Save user message
        const userMessage = input.messages[input.messages.length - 1];
        if (userMessage && userMessage.role === "user") {
          await db.addChatMessage(ctx.user.id, "user", userMessage.content);
        }

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "Você é um assistente nutricional especializado em nutrição, exercícios e saúde. Ajude o usuário com dúvidas sobre a plataforma NutriAI, nutrição, dietas, exercícios e objetivos de saúde. Seja amigável, claro e objetivo. Responda sempre em português brasileiro.",
            },
            ...input.messages,
          ],
        });
        const content = response.choices[0].message.content;
        const assistantResponse = typeof content === 'string' ? content : "Desculpe, não consegui processar sua mensagem.";
        
        // Save assistant response
        await db.addChatMessage(ctx.user.id, "assistant", assistantResponse);
        
        return { response: assistantResponse };
      }),

    getChatHistory: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(({ ctx, input }) =>
        db.getChatHistory(ctx.user.id, input.limit)
      ),

    clearChatHistory: protectedProcedure
      .mutation(({ ctx }) =>
        db.clearChatHistory(ctx.user.id)
      ),

    generateMealPlan: protectedProcedure
      .input(z.object({
        dietType: z.string(),
        dailyCalories: z.number(),
        preferences: z.string().optional(),
        allergies: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "You are a professional nutritionist. Create a detailed meal plan in JSON format with breakfast, lunch, dinner, and snacks. Each meal should include foods and estimated calories.",
            },
            {
              role: "user",
              content: `Create a ${input.dietType} meal plan for ${input.dailyCalories} calories per day. Preferences: ${input.preferences || "none"}. Allergies: ${input.allergies || "none"}.`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "meal_plan",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  breakfast: {
                    type: "array",
                    items: { type: "string" },
                  },
                  lunch: {
                    type: "array",
                    items: { type: "string" },
                  },
                  dinner: {
                    type: "array",
                    items: { type: "string" },
                  },
                  snacks: {
                    type: "array",
                    items: { type: "string" },
                  },
                  totalCalories: { type: "number" },
                },
                required: ["breakfast", "lunch", "dinner", "snacks", "totalCalories"],
              },
            },
          },
        });
        const content = response.choices[0].message.content;
        return JSON.parse(typeof content === 'string' ? content : "{}");
      }),
  }),

  notifications: router({
    getAll: protectedProcedure
      .input(z.object({ limit: z.number().default(20) }))
      .query(({ ctx, input }) =>
        db.getNotifications(ctx.user.id, input.limit)
      ),
    create: protectedProcedure
      .input(z.object({
        type: z.enum(["calorie_goal", "water_reminder", "macro_alert", "weight_milestone", "general"]),
        title: z.string(),
        message: z.string().optional(),
        actionUrl: z.string().optional(),
      }))
      .mutation(({ ctx, input }) =>
        db.createNotification({
          userId: ctx.user.id,
          ...input,
        })
      ),
    markAsRead: protectedProcedure
      .input(z.number())
      .mutation(({ input }) =>
        db.markNotificationAsRead(input)
      ),
    delete: protectedProcedure
      .input(z.number())
      .mutation(({ input }) =>
        db.deleteNotification(input)
      ),
  }),

  notificationPreferences: router({
    get: protectedProcedure.query(({ ctx }) =>
      db.getNotificationPreferences(ctx.user.id)
    ),
    update: protectedProcedure
      .input(z.object({
        enableCalorieAlerts: z.boolean().optional(),
        enableWaterReminders: z.boolean().optional(),
        enableMacroAlerts: z.boolean().optional(),
        enableWeightMilestones: z.boolean().optional(),
        calorieAlertThreshold: z.number().optional(),
        waterReminderInterval: z.number().optional(),
        notificationSound: z.boolean().optional(),
      }))
      .mutation(({ ctx, input }) =>
        db.upsertNotificationPreferences(ctx.user.id, input)
      ),
  }),

  subscription: router({
    createCheckoutSession: protectedProcedure
      .mutation(async ({ ctx }) => {
        const Stripe = (await import("stripe")).default;
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2025-11-17.clover" });
        const { PRODUCTS } = await import("./products");

        // Create or retrieve Stripe customer
        let customerId = ctx.user.stripeCustomerId;
        if (!customerId) {
          const customer = await stripe.customers.create({
            email: ctx.user.email || undefined,
            name: ctx.user.name || undefined,
            metadata: {
              userId: ctx.user.id.toString(),
            },
          });
          customerId = customer.id;
          await db.updateUserStripeCustomer(ctx.user.id, customerId);
        }

        // Create checkout session
        const session = await stripe.checkout.sessions.create({
          customer: customerId,
          client_reference_id: ctx.user.id.toString(),
          mode: "subscription",
          payment_method_types: ["card"],
          line_items: [
            {
              price_data: {
                currency: PRODUCTS.PREMIUM.currency,
                product_data: {
                  name: PRODUCTS.PREMIUM.name,
                  description: PRODUCTS.PREMIUM.description,
                },
                unit_amount: PRODUCTS.PREMIUM.amount,
                recurring: {
                  interval: PRODUCTS.PREMIUM.interval,
                },
              },
              quantity: 1,
            },
          ],
          success_url: `${ctx.req.headers.origin}/?success=true`,
          cancel_url: `${ctx.req.headers.origin}/pricing?canceled=true`,
          allow_promotion_codes: true,
          metadata: {
            userId: ctx.user.id.toString(),
            userEmail: ctx.user.email || "",
            userName: ctx.user.name || "",
          },
        });

        return { url: session.url };
      }),

    getStatus: protectedProcedure
      .query(({ ctx }) => ({
        plan: ctx.user.subscriptionPlan,
        status: ctx.user.subscriptionStatus,
        endsAt: ctx.user.subscriptionEndsAt,
      })),

    cancelSubscription: protectedProcedure
      .mutation(async ({ ctx }) => {
        if (!ctx.user.stripeSubscriptionId) {
          throw new Error("Nenhuma assinatura ativa encontrada");
        }

        const Stripe = (await import("stripe")).default;
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2025-11-17.clover" });

        await stripe.subscriptions.update(ctx.user.stripeSubscriptionId, {
          cancel_at_period_end: true,
        });

        return { success: true };
      }),
  }),

  water: router({
    add: protectedProcedure
      .input(z.object({
        amount: z.number(),
        date: z.string(),
      }))
      .mutation(({ ctx, input }) =>
        db.addWaterIntake(ctx.user.id, input.amount, input.date)
      ),
    getForDay: protectedProcedure
      .input(z.object({ date: z.string() }))
      .query(({ ctx, input }) =>
        db.getWaterIntakeForDay(ctx.user.id, input.date)
      ),
    getTotalForDay: protectedProcedure
      .input(z.object({ date: z.string() }))
      .query(({ ctx, input }) =>
        db.getTotalWaterForDay(ctx.user.id, input.date)
      ),
  }),
});

export type AppRouter = typeof appRouter;
