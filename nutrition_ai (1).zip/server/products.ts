/**
 * Stripe Product and Price Configuration
 * Centralized definition of products and prices for the NutriAI subscription system
 */

export const PRODUCTS = {
  PREMIUM: {
    name: "NutriAI Premium",
    description: "Acesso completo a todas as funcionalidades premium do NutriAI",
    priceId: process.env.STRIPE_PREMIUM_PRICE_ID || "price_premium_monthly", // Will be created in Stripe
    amount: 999, // R$ 9.99 in cents
    currency: "brl",
    interval: "month" as const,
    features: [
      "Análise de fotos com IA",
      "Chat assistente de nutrição",
      "Sistema completo de exercícios",
      "Controle de água",
      "Gráficos e histórico ilimitado",
      "Planos alimentares personalizados",
      "Notificações personalizadas",
      "Suporte prioritário",
    ],
  },
} as const;

export const FREE_PLAN_FEATURES = [
  "Adicionar calorias manualmente",
  "Calculadora de IMC",
  "Calculadora de MMC",
  "Calculadora de TMB",
  "Calculadora de TDEE",
  "Visualização básica do dashboard",
] as const;
