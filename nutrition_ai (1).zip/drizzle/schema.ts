import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, date } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  subscriptionPlan: mysqlEnum("subscriptionPlan", ["free", "premium"]).default("free").notNull(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  subscriptionStatus: mysqlEnum("subscriptionStatus", ["active", "canceled", "past_due", "trialing", "incomplete"]),
  subscriptionEndsAt: timestamp("subscriptionEndsAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// User Profile Table
export const userProfiles = mysqlTable("userProfiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  weight: int("weight"), // em kg
  height: int("height"), // em cm
  age: int("age"),
  gender: mysqlEnum("gender", ["male", "female", "other"]),
  objective: mysqlEnum("objective", ["lose", "maintain", "gain"]),
  dietType: mysqlEnum("dietType", ["normal", "vegan", "vegetarian", "lowcarb", "keto", "highprotein"]).default("normal"),
  dailyCalorieGoal: int("dailyCalorieGoal"),
  profilePhoto: text("profilePhoto"),
  allergies: text("allergies"), // JSON array
  preferences: text("preferences"), // JSON array
  budget: int("budget"), // orçamento diário em centavos
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = typeof userProfiles.$inferInsert;

// Foods Database Table
export const foods = mysqlTable("foods", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }), // ex: "Frutas", "Proteínas", "Carboidratos"
  calories: int("calories"), // por 100g
  protein: int("protein"), // em gramas por 100g
  carbs: int("carbs"), // em gramas por 100g
  fat: int("fat"), // em gramas por 100g
  fiber: int("fiber"), // em gramas por 100g
  sugar: int("sugar"), // em gramas por 100g
  servingSize: int("servingSize"), // em gramas
  source: varchar("source", { length: 100 }), // "database", "user_added", "restaurant"
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Food = typeof foods.$inferSelect;
export type InsertFood = typeof foods.$inferInsert;

// Meals Table (Refeições do dia)
export const meals = mysqlTable("meals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  mealType: mysqlEnum("mealType", ["breakfast", "lunch", "dinner", "snack", "other"]).notNull(),
  date: date("date").notNull(),
  totalCalories: int("totalCalories").default(0),
  totalProtein: int("totalProtein").default(0),
  totalCarbs: int("totalCarbs").default(0),
  totalFat: int("totalFat").default(0),
  notes: text("notes"),
  photoUrl: text("photoUrl"), // URL da foto do prato
  aiAnalysis: text("aiAnalysis"), // JSON com análise da IA
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Meal = typeof meals.$inferSelect;
export type InsertMeal = typeof meals.$inferInsert;

// Meal Items Table (Itens dentro de uma refeição)
export const mealItems = mysqlTable("mealItems", {
  id: int("id").autoincrement().primaryKey(),
  mealId: int("mealId").notNull(),
  foodId: int("foodId").notNull(),
  quantity: int("quantity"), // em gramas
  calories: int("calories"),
  protein: int("protein"),
  carbs: int("carbs"),
  fat: int("fat"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MealItem = typeof mealItems.$inferSelect;
export type InsertMealItem = typeof mealItems.$inferInsert;

// Exercises Table
export const exercises = mysqlTable("exercises", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }), // ex: "Cardio", "Força", "Flexibilidade"
  caloriesBurnedPerMinute: int("caloriesBurnedPerMinute"), // média de calorias queimadas por minuto
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Exercise = typeof exercises.$inferSelect;
export type InsertExercise = typeof exercises.$inferInsert;

// User Exercises Table (Exercícios realizados pelo usuário)
export const userExercises = mysqlTable("userExercises", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  exerciseId: int("exerciseId").notNull(),
  date: date("date").notNull(),
  duration: int("duration"), // em minutos
  caloriesBurned: int("caloriesBurned"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserExercise = typeof userExercises.$inferSelect;
export type InsertUserExercise = typeof userExercises.$inferInsert;

// Weight History Table (Histórico de peso)
export const weightHistory = mysqlTable("weightHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  weight: int("weight"), // em kg
  date: date("date").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WeightHistory = typeof weightHistory.$inferSelect;
export type InsertWeightHistory = typeof weightHistory.$inferInsert;

// Meal Plans Table (Planos alimentares gerados por IA)
export const mealPlans = mysqlTable("mealPlans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }),
  description: text("description"),
  dietType: varchar("dietType", { length: 100 }),
  dailyCalories: int("dailyCalories"),
  plan: text("plan"), // JSON com o plano completo
  isActive: boolean("isActive").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MealPlan = typeof mealPlans.$inferSelect;
export type InsertMealPlan = typeof mealPlans.$inferInsert;

// Notifications Table
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["calorie_goal", "water_reminder", "macro_alert", "weight_milestone", "general"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  isRead: boolean("isRead").default(false),
  actionUrl: varchar("actionUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// Notification Preferences Table
export const notificationPreferences = mysqlTable("notificationPreferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  enableCalorieAlerts: boolean("enableCalorieAlerts").default(true),
  enableWaterReminders: boolean("enableWaterReminders").default(true),
  enableMacroAlerts: boolean("enableMacroAlerts").default(true),
  enableWeightMilestones: boolean("enableWeightMilestones").default(true),
  calorieAlertThreshold: int("calorieAlertThreshold").default(100), // % da meta
  waterReminderInterval: int("waterReminderInterval").default(120), // minutos
  notificationSound: boolean("notificationSound").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NotificationPreference = typeof notificationPreferences.$inferSelect;
export type InsertNotificationPreference = typeof notificationPreferences.$inferInsert;

// Water Intake Table (Registro de consumo de água)
export const waterIntake = mysqlTable("waterIntake", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  amount: int("amount").notNull(), // em ml
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WaterIntake = typeof waterIntake.$inferSelect;
export type InsertWaterIntake = typeof waterIntake.$inferInsert;

// Chat History Table (Histórico de conversações com IA)
export const chatHistory = mysqlTable("chatHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatHistory = typeof chatHistory.$inferSelect;
export type InsertChatHistory = typeof chatHistory.$inferInsert;
