CREATE TABLE `exercises` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` varchar(100),
	`caloriesBurnedPerMinute` int,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `exercises_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `foods` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` varchar(100),
	`calories` int,
	`protein` int,
	`carbs` int,
	`fat` int,
	`fiber` int,
	`sugar` int,
	`servingSize` int,
	`source` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `foods_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mealItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`mealId` int NOT NULL,
	`foodId` int NOT NULL,
	`quantity` int,
	`calories` int,
	`protein` int,
	`carbs` int,
	`fat` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mealItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mealPlans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255),
	`description` text,
	`dietType` varchar(100),
	`dailyCalories` int,
	`plan` text,
	`isActive` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `mealPlans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `meals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`mealType` enum('breakfast','lunch','dinner','snack','other') NOT NULL,
	`date` date NOT NULL,
	`totalCalories` int DEFAULT 0,
	`totalProtein` int DEFAULT 0,
	`totalCarbs` int DEFAULT 0,
	`totalFat` int DEFAULT 0,
	`notes` text,
	`photoUrl` text,
	`aiAnalysis` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `meals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userExercises` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`exerciseId` int NOT NULL,
	`date` date NOT NULL,
	`duration` int,
	`caloriesBurned` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `userExercises_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userProfiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`weight` int,
	`height` int,
	`age` int,
	`gender` enum('male','female','other'),
	`objective` enum('lose','maintain','gain'),
	`dietType` enum('normal','vegan','vegetarian','lowcarb','keto','highprotein') DEFAULT 'normal',
	`dailyCalorieGoal` int,
	`profilePhoto` text,
	`allergies` text,
	`preferences` text,
	`budget` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userProfiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `userProfiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `weightHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`weight` int,
	`date` date NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `weightHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `subscriptionPlan` enum('free','premium') DEFAULT 'free' NOT NULL;