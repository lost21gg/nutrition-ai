import mysql from 'mysql2/promise';

const foods = [
  // Frutas
  { name: 'Maçã', category: 'Frutas', calories: 52, protein: 0, carbs: 14, fat: 0, fiber: 2, sugar: 10, servingSize: 100 },
  { name: 'Banana', category: 'Frutas', calories: 89, protein: 1, carbs: 23, fat: 0, fiber: 3, sugar: 12, servingSize: 100 },
  { name: 'Laranja', category: 'Frutas', calories: 47, protein: 1, carbs: 12, fat: 0, fiber: 2, sugar: 9, servingSize: 100 },
  { name: 'Morango', category: 'Frutas', calories: 32, protein: 1, carbs: 8, fat: 0, fiber: 2, sugar: 7, servingSize: 100 },
  { name: 'Melancia', category: 'Frutas', calories: 30, protein: 1, carbs: 8, fat: 0, fiber: 0, sugar: 6, servingSize: 100 },
  { name: 'Abacaxi', category: 'Frutas', calories: 50, protein: 0, carbs: 13, fat: 0, fiber: 1, sugar: 10, servingSize: 100 },
  { name: 'Uva', category: 'Frutas', calories: 67, protein: 1, carbs: 17, fat: 0, fiber: 1, sugar: 16, servingSize: 100 },
  { name: 'Mamão', category: 'Frutas', calories: 43, protein: 1, carbs: 11, fat: 0, fiber: 2, sugar: 7, servingSize: 100 },
  { name: 'Manga', category: 'Frutas', calories: 60, protein: 1, carbs: 15, fat: 0, fiber: 2, sugar: 13, servingSize: 100 },
  { name: 'Abacate', category: 'Frutas', calories: 160, protein: 2, carbs: 9, fat: 15, fiber: 7, sugar: 0, servingSize: 100 },

  // Proteínas
  { name: 'Peito de Frango', category: 'Proteínas', calories: 165, protein: 31, carbs: 0, fat: 4, fiber: 0, sugar: 0, servingSize: 100 },
  { name: 'Carne Vermelha Magra', category: 'Proteínas', calories: 250, protein: 26, carbs: 0, fat: 15, fiber: 0, sugar: 0, servingSize: 100 },
  { name: 'Peixe (Salmão)', category: 'Proteínas', calories: 208, protein: 20, carbs: 0, fat: 13, fiber: 0, sugar: 0, servingSize: 100 },
  { name: 'Ovo', category: 'Proteínas', calories: 155, protein: 13, carbs: 1, fat: 11, fiber: 0, sugar: 1, servingSize: 100 },
  { name: 'Iogurte Grego', category: 'Proteínas', calories: 59, protein: 10, carbs: 3, fat: 0, fiber: 0, sugar: 3, servingSize: 100 },
  { name: 'Queijo Branco', category: 'Proteínas', calories: 110, protein: 20, carbs: 1, fat: 3, fiber: 0, sugar: 0, servingSize: 100 },
  { name: 'Feijão', category: 'Proteínas', calories: 127, protein: 9, carbs: 23, fat: 0, fiber: 6, sugar: 0, servingSize: 100 },
  { name: 'Lentilha', category: 'Proteínas', calories: 116, protein: 9, carbs: 20, fat: 0, fiber: 8, sugar: 2, servingSize: 100 },
  { name: 'Tofu', category: 'Proteínas', calories: 76, protein: 8, carbs: 2, fat: 5, fiber: 1, sugar: 0, servingSize: 100 },
  { name: 'Amendoim', category: 'Proteínas', calories: 567, protein: 26, carbs: 16, fat: 49, fiber: 9, sugar: 4, servingSize: 100 },

  // Carboidratos
  { name: 'Arroz Integral', category: 'Carboidratos', calories: 111, protein: 3, carbs: 23, fat: 1, fiber: 4, sugar: 0, servingSize: 100 },
  { name: 'Pão Integral', category: 'Carboidratos', calories: 247, protein: 9, carbs: 41, fat: 3, fiber: 7, sugar: 4, servingSize: 100 },
  { name: 'Batata Doce', category: 'Carboidratos', calories: 86, protein: 2, carbs: 20, fat: 0, fiber: 3, sugar: 4, servingSize: 100 },
  { name: 'Batata Branca', category: 'Carboidratos', calories: 77, protein: 2, carbs: 17, fat: 0, fiber: 2, sugar: 1, servingSize: 100 },
  { name: 'Macarrão Integral', category: 'Carboidratos', calories: 124, protein: 5, carbs: 25, fat: 1, fiber: 5, sugar: 1, servingSize: 100 },
  { name: 'Aveia', category: 'Carboidratos', calories: 389, protein: 17, carbs: 66, fat: 7, fiber: 11, sugar: 0, servingSize: 100 },
  { name: 'Milho', category: 'Carboidratos', calories: 86, protein: 3, carbs: 19, fat: 1, fiber: 2, sugar: 3, servingSize: 100 },
  { name: 'Brócolis', category: 'Carboidratos', calories: 34, protein: 3, carbs: 7, fat: 0, fiber: 2, sugar: 1, servingSize: 100 },
  { name: 'Cenoura', category: 'Carboidratos', calories: 41, protein: 1, carbs: 10, fat: 0, fiber: 3, sugar: 6, servingSize: 100 },
  { name: 'Abóbora', category: 'Carboidratos', calories: 26, protein: 1, carbs: 7, fat: 0, fiber: 1, sugar: 1, servingSize: 100 },

  // Gorduras Saudáveis
  { name: 'Azeite de Oliva', category: 'Gorduras', calories: 884, protein: 0, carbs: 0, fat: 100, fiber: 0, sugar: 0, servingSize: 10 },
  { name: 'Castanha do Pará', category: 'Gorduras', calories: 656, protein: 14, carbs: 12, fat: 66, fiber: 8, sugar: 2, servingSize: 100 },
  { name: 'Nozes', category: 'Gorduras', calories: 654, protein: 9, carbs: 14, fat: 65, fiber: 7, sugar: 3, servingSize: 100 },
  { name: 'Sementes de Chia', category: 'Gorduras', calories: 486, protein: 17, carbs: 42, fat: 31, fiber: 34, sugar: 3, servingSize: 100 },
  { name: 'Coco', category: 'Gorduras', calories: 354, protein: 3, carbs: 15, fat: 33, fiber: 9, sugar: 9, servingSize: 100 },

  // Refeições Rápidas
  { name: 'Sanduíche de Frango', category: 'Refeições', calories: 350, protein: 25, carbs: 35, fat: 12, fiber: 2, sugar: 5, servingSize: 200 },
  { name: 'Salada Verde', category: 'Refeições', calories: 25, protein: 2, carbs: 5, fat: 0, fiber: 1, sugar: 1, servingSize: 100 },
  { name: 'Sopa de Legumes', category: 'Refeições', calories: 40, protein: 2, carbs: 8, fat: 0, fiber: 2, sugar: 2, servingSize: 200 },
  { name: 'Açaí com Granola', category: 'Refeições', calories: 280, protein: 8, carbs: 35, fat: 12, fiber: 4, sugar: 20, servingSize: 200 },
  { name: 'Vitamina de Frutas', category: 'Refeições', calories: 120, protein: 3, carbs: 28, fat: 1, fiber: 2, sugar: 20, servingSize: 250 },

  // Bebidas
  { name: 'Leite Integral', category: 'Bebidas', calories: 61, protein: 3, carbs: 5, fat: 3, fiber: 0, sugar: 5, servingSize: 100 },
  { name: 'Leite Desnatado', category: 'Bebidas', calories: 35, protein: 4, carbs: 5, fat: 0, fiber: 0, sugar: 5, servingSize: 100 },
  { name: 'Suco Natural de Laranja', category: 'Bebidas', calories: 45, protein: 1, carbs: 11, fat: 0, fiber: 0, sugar: 9, servingSize: 100 },
  { name: 'Café', category: 'Bebidas', calories: 2, protein: 0, carbs: 0, fat: 0, fiber: 0, sugar: 0, servingSize: 100 },
  { name: 'Chá Verde', category: 'Bebidas', calories: 2, protein: 0, carbs: 0, fat: 0, fiber: 0, sugar: 0, servingSize: 100 },

  // Restaurantes Populares
  { name: 'Hambúrguer (Restaurante)', category: 'Restaurantes', calories: 540, protein: 28, carbs: 41, fat: 28, fiber: 2, sugar: 8, servingSize: 200 },
  { name: 'Pizza (1 fatia)', category: 'Restaurantes', calories: 285, protein: 12, carbs: 36, fat: 10, fiber: 2, sugar: 3, servingSize: 100 },
  { name: 'Frango Frito (Restaurante)', category: 'Restaurantes', calories: 320, protein: 30, carbs: 10, fat: 18, fiber: 0, sugar: 0, servingSize: 150 },
  { name: 'Prato Feito (Arroz, Feijão, Carne)', category: 'Restaurantes', calories: 450, protein: 30, carbs: 50, fat: 15, fiber: 5, sugar: 2, servingSize: 350 },
  { name: 'Pastel Frito', category: 'Restaurantes', calories: 280, protein: 8, carbs: 30, fat: 15, fiber: 1, sugar: 2, servingSize: 100 },
];

async function seedFoods() {
  try {
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'nutrition_ai',
    });

    console.log('Conectado ao banco de dados');

    // Limpar tabela de alimentos existentes
    await connection.execute('DELETE FROM foods');
    console.log('Tabela de alimentos limpa');

    // Inserir novos alimentos
    for (const food of foods) {
      await connection.execute(
        'INSERT INTO foods (name, category, calories, protein, carbs, fat, fiber, sugar, servingSize, source) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [food.name, food.category, food.calories, food.protein, food.carbs, food.fat, food.fiber, food.sugar, food.servingSize, 'database']
      );
    }

    console.log(`${foods.length} alimentos inseridos com sucesso!`);
    await connection.end();
  } catch (error) {
    console.error('Erro ao popular banco de dados:', error);
    process.exit(1);
  }
}

seedFoods();
