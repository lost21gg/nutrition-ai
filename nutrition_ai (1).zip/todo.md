# NutriAI - TODO List

## Fase 1: Arquitetura e Banco de Dados
- [x] Definir schema do banco de dados (usuários, alimentos, refeições, exercícios, etc.)
- [x] Criar tabelas: users, userProfiles, foods, meals, mealItems, exercises, userExercises, mealHistory
- [x] Implementar migrations do Drizzle
- [x] Criar helpers de banco de dados em server/db.ts

## Fase 2: Autenticação e Perfil
- [x] Implementar login/cadastro com OAuth Manus (já incluído no template)
- [x] Criar página de perfil do usuário
- [x] Adicionar campos: foto, peso, altura, idade, objetivo, preferências alimentares, alergias
- [x] Implementar edição de perfil
- [x] Criar banco de dados de alimentos brasileiros (seed data)
- [x] Adicionar funcionalidade de busca de alimentos

## Fase 3: Dashboard Principal
- [x] Criar dashboard com resumo do dia
- [x] Exibir calorias consumidas vs meta diária
- [x] Mostrar macronutrientes (proteínas, carboidratos, gorduras)
- [x] Adicionar indicador de água consumida
- [x] Criar gráficos de progresso (peso, calorias, macros)
- [x] Exibir objetivo atual (emagrecer/manter/ganhar massa)
- [ ] Implementar histórico dos últimos dias

## Fase 4: Calculadoras e Registro Diário
- [x] Criar calculadora de IMC (Índice de Massa Corporal)
- [x] Criar calculadora de MMC (Meta de Massa Corporal)
- [x] Implementar cálculo de TMB (Taxa Metabólica Basal)
- [x] Implementar cálculo de TDEE (Gasto Calórico Total Diário)
- [x] Criar sistema de registro de refeições (café, almoço, jantar, lanches, snacks)
- [x] Adicionar funcionalidade de busca de alimentos no banco de dados
- [x] Implementar adição manual de alimentos
- [x] Criar visualização de barras de progresso

## Fase 5: IA para Análise de Fotos e Planos Alimentares
- [ ] Implementar ferramenta de upload de foto do prato
- [ ] Integrar IA para detectar alimentos na foto
- [ ] Implementar estimativa de calorias por IA
- [ ] Gerar análise de macronutrientes da foto
- [ ] Gerar sugestões de ajuste (ex: "reduza o óleo para diminuir 120 kcal")
- [ ] Criar sistema de geração de planos alimentares personalizados por IA
- [ ] Considerar: peso, altura, idade, objetivo, tipo de dieta, preferências, alergias, orçamento

## Fase 6: Sistema de Exercícios
- [ ] Criar lista de exercícios com calorias gastas
- [ ] Implementar cálculo automático de calorias gastas por tempo
- [ ] Criar sugestões de treinos baseadas no objetivo
- [ ] Implementar registro diário de exercícios
- [ ] Adicionar histórico de exercícios

## Fase 7: Funcionalidades Premium e Admin
- [ ] Implementar sistema de planos (free vs premium)
- [ ] Desbloquear análise avançada de refeição por IA (premium)
- [ ] Desbloquear planos alimentares completos (premium)
- [ ] Desbloquear gráficos avançados (premium)
- [ ] Implementar exportação de dados em PDF (premium)
- [ ] Implementar recomendações diárias personalizadas (premium)
- [ ] Criar painel admin para gerenciar alimentos
- [ ] Criar painel admin para gerenciar usuários
- [ ] Implementar testes com Vitest

## Fase 8: Design e Testes Finais
- [ ] Implementar design estilo Yazio (clean, cores suaves, ícones ilustrativos)
- [ ] Garantir responsividade para mobile
- [ ] Adicionar animações leves
- [ ] Testar todas as funcionalidades
- [ ] Corrigir bugs
- [ ] Otimizar performance
- [ ] Criar checkpoint final

## Requisitos Técnicos
- [ ] Layout moderno estilo Yazio
- [ ] Totalmente responsivo
- [ ] Animações leves
- [ ] Código organizado
- [ ] Backend seguro
- [ ] Possível integração com API externa de alimentos
- [ ] Painel admin funcional


## Bugs Reportados
- [x] Sistema de tirar foto do prato não está funcionando - implementar página de captura com integração IA
- [x] Erro ao salvar refeição com foto - base64 muito grande para o campo photoUrl


## Fase 8: Sistema de Notificações Personalizadas
- [x] Criar tabela de notificações no banco de dados
- [x] Implementar procedimentos tRPC para gerenciar notificações
- [x] Criar componente de notificações em tempo real
- [x] Adicionar notificações de meta de calorias
- [x] Adicionar notificações de hidratação (água)
- [x] Adicionar notificações de macronutrientes
- [x] Implementar preferências de notificação no perfil
- [x] Criar centro de notificações (notification center)
- [x] Adicionar sons e visuais para notificações


## Fase 9: Melhorias no Dashboard e Persistência de Dados
- [x] Atualizar dashboard para somar calorias das refeições do dia
- [x] Remover meta de calorias do indicador
- [x] Limpar gráfico de 7 dias - mostrar apenas dados reais
- [x] Funcionalizar sistema de adicionar treino com salvamento automático
- [x] Garantir que refeições salvam automaticamente no banco
- [x] Garantir que exercícios salvam automaticamente no banco
- [x] Atualizar dashboard em tempo real quando dados são adicionados


## Fase 10: Redesign para Aparência de App Mobile
- [x] Criar bottom navigation bar (Home, Refeições, Estatísticas, Perfil)
- [x] Remover header tradicional e adicionar navegação inferior
- [x] Ajustar layout para parecer app mobile nativo
- [x] Adicionar ícones modernos na navegação
- [x] Melhorar espaçamento e padding para mobile
- [x] Adicionar transições suaves entre páginas
- [x] Criar componente de layout compartilhado com bottom nav


## Fase 11: Redesign Profissional e Elegante da Página Home
- [x] Criar hero section com gradiente moderno
- [x] Adicionar cards de features com ícones elegantes
- [x] Implementar animações sutis e transições suaves
- [x] Melhorar tipografia e hierarquia visual
- [x] Adicionar imagens ou ilustrações de alta qualidade
- [x] Criar CTA (Call-to-Action) destacado e profissional

- [x] Melhorar visual do Dashboard com design mais elegante
- [x] Adicionar gradientes sutis e sombras suaves
- [x] Melhorar card de calorias líquidas com design circular
- [x] Adicionar ícones coloridos nos quick stats
- [x] Melhorar barras de progresso de macronutrientes


## Fase 12: IA de Suporte, Mais Dados e Correções
- [x] Criar chatbot de IA para tirar dúvidas sobre nutrição e plataforma
- [x] Adicionar interface de chat flutuante ou em página dedicada
- [x] Expandir banco de dados de exercícios (adicionar 40+ exercícios)
- [x] Expandir banco de dados de alimentos (adicionar 90+ alimentos brasileiros)
- [x] Corrigir sistema de captura de câmera na página de foto
- [x] Testar captura de foto em diferentes dispositivos


## Bugs Reportados (Fase 13)
- [x] Erro de console: setState sendo chamado durante render na página Home


## Fase 14: Expansão Massiva do Banco de Alimentos
- [x] Adicionar todos os tipos de carnes (bovina, suína, aves, peixes, frutos do mar)
- [x] Adicionar todas as verduras comuns brasileiras
- [x] Adicionar todos os legumes comuns brasileiros
- [x] Adicionar todas as frutas tropicais e comuns
- [x] Adicionar cereais, grãos e massas
- [x] Adicionar laticínios completos
- [x] Adicionar oleaginosas e sementes
- [x] Adicionar temperos e condimentos (incluídos em verduras)
- [x] Adicionar bebidas diversas (já adicionadas anteriormente)
- [x] Adicionar fast food e comidas industrializadas


## Bugs Críticos (Fase 15)
- [x] Erro NotFoundError: removeChild no domínio nutriai.icu - investigar componentes com problemas de unmount


## Fase 16: Funcionalidades de Água, Exercícios e Câmera
- [x] Implementar sistema funcional de registro de água com botões rápidos (+250ml, +500ml, +1L)
- [x] Calcular calorias queimadas baseado no tipo de exercício e duração
- [x] Corrigir sistema de câmera para funcionar corretamente em mobile
- [x] Adicionar persistência de água no banco de dados
- [x] Mostrar progresso de água no dashboard


## Fase 17: Melhorias de Layout, Tema e Funcionalidades
- [x] Implementar sistema de tema claro/escuro com alternador no perfil
- [ ] Adicionar mais elementos visuais ao dashboard e páginas
- [ ] Melhorar paleta de cores para tema escuro
- [ ] Melhorar paleta de cores para tema claro
- [x] Corrigir sistema de contabilização de água (não está somando)
- [x] Adicionar histórico de conversações no chat de IA
- [x] Salvar mensagens do chat no banco de dados
- [x] Carregar histórico ao abrir o chat


## Bugs Reportados (Fase 18)
- [x] Sistema de água não está exibindo valores quando usuário clica em 1L ou outros botões

- [x] Câmera não abre quando clica em "Tirar Foto" mesmo com permissão concedida (resolvido com input capture nativo)

- [x] Foto tirada não aparece no preview e botão de analisar não aparece (RESOLVIDO - reescrito com solução simples)

- [x] IA identifica alimentos mas não retorna calorias, proteínas, carboidratos e gorduras (RESOLVIDO - corrigido mapeamento de campos)


## Fase 19: Sistema de Planos Grátis e Premium com Stripe
- [x] Adicionar feature Stripe ao projeto com webdev_add_feature
- [x] Criar tabela de assinaturas (subscriptions) no banco de dados
- [x] Adicionar campo subscriptionTier ao schema de users (free/premium)
- [x] Implementar procedimentos tRPC para gerenciar assinaturas
- [x] Criar página de planos (/pricing) com cards Free e Premium
- [x] Integrar Stripe Checkout para pagamento de R$ 9,99/mês
- [ ] Implementar webhook do Stripe para atualizar status de assinatura
- [x] Adicionar restrições de acesso baseadas no plano:
  - [x] Bloquear análise de fotos para plano grátis
  - [x] Bloquear chat de IA para plano grátis
  - [x] Bloquear sistema de exercícios para plano grátis
  - [x] Bloquear controle de água para plano grátis
  - [x] Permitir apenas adição manual de calorias e calculadoras no plano grátis
- [x] Adicionar badge "Premium" no perfil de usuários pagantes
- [x] Criar modal de upgrade quando usuário grátis tenta acessar recurso premium
- [x] Adicionar link para página de planos na navegação
- [ ] Testar fluxo completo de assinatura
