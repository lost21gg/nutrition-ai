import { Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useLocation } from "wouter";

interface UpgradeModalProps {
  open: boolean;
  onClose: () => void;
  feature: string;
}

export function UpgradeModal({ open, onClose, feature }: UpgradeModalProps) {
  const [, setLocation] = useLocation();

  const handleUpgrade = () => {
    onClose();
    setLocation("/pricing");
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-primary" />
              <DialogTitle>Recurso Premium</DialogTitle>
            </div>
          </div>
          <DialogDescription>
            {feature} é um recurso exclusivo do plano Premium.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="bg-gradient-to-r from-primary/10 to-primary/5 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Com o Premium você tem acesso a:</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Análise de fotos com IA</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Chat assistente de nutrição</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Sistema completo de exercícios</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Controle de água e muito mais</span>
              </li>
            </ul>
          </div>

          <div className="text-center">
            <p className="text-2xl font-bold mb-1">
              <span className="bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                R$ 9,99
              </span>
              <span className="text-sm text-muted-foreground ml-1">/mês</span>
            </p>
            <p className="text-xs text-muted-foreground">Cancele quando quiser</p>
          </div>
        </div>

        <div className="flex gap-3">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Agora não
          </Button>
          <Button onClick={handleUpgrade} className="flex-1 bg-gradient-to-r from-primary to-primary/80">
            Assinar Premium
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
