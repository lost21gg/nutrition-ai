import { MessageCircle } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "./ui/button";

export function FloatingChatButton() {
  const [, setLocation] = useLocation();

  return (
    <Button
      onClick={() => setLocation("/chat")}
      size="lg"
      className="fixed bottom-20 right-4 w-14 h-14 rounded-full shadow-lg shadow-primary/30 bg-gradient-to-br from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 z-40 p-0"
    >
      <MessageCircle className="w-6 h-6" />
    </Button>
  );
}
