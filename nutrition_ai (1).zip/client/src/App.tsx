import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Calculators from "./pages/Calculators";
import Meals from "./pages/Meals";
import MealPhoto from "./pages/MealPhoto";
import Profile from "./pages/Profile";
import NotificationSettings from "./pages/NotificationSettings";
import AIChat from "./pages/AIChat";
import Pricing from "./pages/Pricing";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/calculators"} component={Calculators} />
      <Route path={"/meals"} component={Meals} />
      <Route path={"/meals/new"} component={Meals} />
      <Route path={"/meals/photo"} component={MealPhoto} />
      <Route path={"/profile"} component={Profile} />
      <Route path={"/notifications"} component={NotificationSettings} />
      <Route path={"/chat"} component={AIChat} />
      <Route path={"/pricing"} component={Pricing} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
