import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Bot, User } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { AppLayout } from "@/components/AppLayout";
import { Streamdown } from "streamdown";
import { UpgradeModal } from "@/components/UpgradeModal";

type Message = {
  role: "user" | "assistant";
  content: string;
};

export default function AIChat() {
  const { isAuthenticated, user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load chat history
  const { data: chatHistory } = trpc.ai.getChatHistory.useQuery(
    { limit: 50 },
    { enabled: isAuthenticated }
  );

  // Initialize messages with history or welcome message
  useEffect(() => {
    if (chatHistory && chatHistory.length > 0) {
      setMessages(chatHistory.map((msg: any) => ({
        role: msg.role,
        content: msg.content,
      })));
    } else if (messages.length === 0) {
      setMessages([{
        role: "assistant",
        content: "Olá! Sou seu assistente nutricional com IA. Posso ajudá-lo com dúvidas sobre nutrição, exercícios, a plataforma NutriAI e muito mais. Como posso ajudar você hoje?",
      }]);
    }
  }, [chatHistory]);

  const chatMutation = trpc.ai.chat.useMutation({
    onSuccess: (data: { response: string }) => {
      setMessages((prev) => [...prev, { role: "assistant", content: data.response }]);
      setIsLoading(false);
    },
    onError: () => {
      toast.error("Erro ao enviar mensagem");
      setIsLoading(false);
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!input.trim() || isLoading) return;

    // Check if user has premium plan
    if (user?.subscriptionPlan !== "premium") {
      setShowUpgradeModal(true);
      return;
    }

    const userMessage = input.trim();
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setInput("");
    setIsLoading(true);

    chatMutation.mutate({
      messages: [...messages, { role: "user", content: userMessage }],
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!isAuthenticated) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center min-h-full p-4">
          <Card>
            <CardHeader>
              <CardTitle>Acesso Negado</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Você precisa estar autenticado para acessar o chat.</p>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="bg-background min-h-full flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-br from-primary/10 to-primary/5 px-4 pt-6 pb-4 border-b border-border/50">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
              <Bot className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Assistente IA</h1>
              <p className="text-sm text-muted-foreground">Tire suas dúvidas sobre nutrição</p>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : "flex-row"}`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.role === "user"
                    ? "bg-primary/20"
                    : "bg-gradient-to-br from-purple-500/20 to-pink-500/20"
                }`}
              >
                {message.role === "user" ? (
                  <User className="w-4 h-4 text-primary" />
                ) : (
                  <Bot className="w-4 h-4 text-purple-500" />
                )}
              </div>
              <Card
                className={`max-w-[80%] ${
                  message.role === "user"
                    ? "bg-primary/10 border-primary/20"
                    : "bg-card border-border/50"
                }`}
              >
                <CardContent className="pt-3 pb-3 px-4">
                  <div className="text-sm">
                    {message.role === "assistant" ? (
                      <Streamdown>{message.content}</Streamdown>
                    ) : (
                      <p className="whitespace-pre-wrap">{message.content}</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
          {isLoading && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-purple-500" />
              </div>
              <Card className="bg-card border-border/50">
                <CardContent className="pt-3 pb-3 px-4">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 rounded-full bg-muted-foreground/50 animate-bounce" style={{ animationDelay: "0ms" }}></div>
                    <div className="w-2 h-2 rounded-full bg-muted-foreground/50 animate-bounce" style={{ animationDelay: "150ms" }}></div>
                    <div className="w-2 h-2 rounded-full bg-muted-foreground/50 animate-bounce" style={{ animationDelay: "300ms" }}></div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="border-t border-border/50 p-4 bg-card/50 backdrop-blur-sm">
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Digite sua pergunta..."
              disabled={isLoading}
              className="flex-1 h-12"
            />
            <Button
              onClick={handleSend}
              disabled={isLoading || !input.trim()}
              size="lg"
              className="h-12 px-6"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2 text-center">
            Pergunte sobre nutrição, exercícios, dietas ou como usar a plataforma
          </p>
        </div>
      </div>

      <UpgradeModal 
        open={showUpgradeModal} 
        onClose={() => setShowUpgradeModal(false)} 
        feature="Chat assistente de IA"
      />
    </AppLayout>
  );
}
