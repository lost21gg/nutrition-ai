import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Apple, Camera, Upload, Loader2, X, Check } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { UpgradeModal } from "@/components/UpgradeModal";

export default function MealPhoto() {
  const { isAuthenticated, user } = useAuth();
  const [, setLocation] = useLocation();
  const [preview, setPreview] = useState("");
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  const analyzeMealMutation = trpc.ai.analyzeMeal.useMutation();
  const createMealMutation = trpc.meals.create.useMutation();

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
      toast.success("Foto carregada!");
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!preview) {
      toast.error("Selecione uma foto primeiro");
      return;
    }

    // Check if user has premium plan
    if (user?.subscriptionPlan !== "premium") {
      setShowUpgradeModal(true);
      return;
    }

    setLoading(true);
    try {
      const result = await analyzeMealMutation.mutateAsync({ photoUrl: preview });
      setAnalysis(result);
      toast.success("Análise concluída!");
    } catch (error) {
      toast.error("Erro ao analisar foto");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!analysis) {
      toast.error("Analise a foto primeiro");
      return;
    }

    try {
      const foodsList = Array.isArray(analysis.foods) ? analysis.foods.join(", ") : analysis.foods || "";
      await createMealMutation.mutateAsync({
        mealType: "other",
        date: new Date().toISOString().split("T")[0],
        totalCalories: analysis.totalCalories || 0,
        totalProtein: analysis.totalProtein || 0,
        totalCarbs: analysis.totalCarbs || 0,
        totalFat: analysis.totalFat || 0,
        notes: `IA: ${foodsList}`,
      });
      toast.success("Refeição salva!");
      setLocation("/");
    } catch (error) {
      toast.error("Erro ao salvar");
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card>
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Você precisa estar autenticado.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <main className="container py-6 max-w-2xl">
        <div className="mb-6">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Camera className="w-6 h-6 text-primary" />
            Analisar Foto
          </h2>
          <p className="text-sm text-muted-foreground">
            Tire uma foto e deixe a IA detectar os alimentos
          </p>
        </div>

        <div className="space-y-4">
          {/* Upload Section */}
          {!preview ? (
            <Card>
              <CardHeader>
                <CardTitle>Capturar Foto</CardTitle>
                <CardDescription>Escolha uma opção abaixo</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <label className="block">
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={handlePhotoChange}
                    className="hidden"
                    id="camera-input"
                  />
                  <Button asChild className="w-full h-14">
                    <label htmlFor="camera-input" className="cursor-pointer">
                      <Camera className="w-5 h-5 mr-2" />
                      Abrir Câmera
                    </label>
                  </Button>
                </label>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t"></div>
                  </div>
                  <div className="relative flex justify-center text-xs">
                    <span className="bg-background px-2 text-muted-foreground">OU</span>
                  </div>
                </div>

                <label className="block">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoChange}
                    className="hidden"
                    id="gallery-input"
                  />
                  <Button asChild variant="outline" className="w-full h-14">
                    <label htmlFor="gallery-input" className="cursor-pointer">
                      <Upload className="w-5 h-5 mr-2" />
                      Enviar da Galeria
                    </label>
                  </Button>
                </label>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Preview Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Foto Selecionada
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setPreview("");
                        setAnalysis(null);
                      }}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <img src={preview} alt="Preview" className="w-full rounded-lg" />
                  <Button
                    onClick={handleAnalyze}
                    disabled={loading}
                    className="w-full mt-4"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Analisando...
                      </>
                    ) : (
                      <>
                        <Apple className="w-4 h-4 mr-2" />
                        Analisar com IA
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Results Section */}
              {analysis && (
                <Card>
                  <CardHeader>
                    <CardTitle>Resultado</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-sm font-medium mb-1">Alimentos:</p>
                      <p className="text-sm text-muted-foreground">
                        {Array.isArray(analysis.foods) ? analysis.foods.join(", ") : analysis.foods || "Não identificado"}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-orange-500/10 p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground">Calorias</p>
                        <p className="text-xl font-bold text-orange-600">
                          {analysis.totalCalories || 0}
                        </p>
                      </div>
                      <div className="bg-blue-500/10 p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground">Proteínas</p>
                        <p className="text-xl font-bold text-blue-600">
                          {analysis.totalProtein || 0}g
                        </p>
                      </div>
                      <div className="bg-yellow-500/10 p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground">Carboidratos</p>
                        <p className="text-xl font-bold text-yellow-600">
                          {analysis.totalCarbs || 0}g
                        </p>
                      </div>
                      <div className="bg-purple-500/10 p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground">Gorduras</p>
                        <p className="text-xl font-bold text-purple-600">
                          {analysis.totalFat || 0}g
                        </p>
                      </div>
                    </div>

                    <Button onClick={handleSave} className="w-full bg-green-600 hover:bg-green-700">
                      <Check className="w-4 h-4 mr-2" />
                      Salvar Refeição
                    </Button>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      </main>

      <UpgradeModal 
        open={showUpgradeModal} 
        onClose={() => setShowUpgradeModal(false)} 
        feature="Análise de fotos com IA"
      />
    </div>
  );
}
