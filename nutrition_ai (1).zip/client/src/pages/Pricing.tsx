import { Check, Sparkles, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { useState } from "react";

const FREE_FEATURES = [
  "Adicionar calorias manualmente",
  "Calculadora de IMC",
  "Calculadora de MMC",
  "Calculadora de TMB",
  "Calculadora de TDEE",
  "Visualização básica do dashboard",
];

const PREMIUM_FEATURES = [
  "Análise de fotos com IA",
  "Chat assistente de nutrição",
  "Sistema completo de exercícios",
  "Controle de água",
  "Gráficos e histórico ilimitado",
  "Planos alimentares personalizados",
  "Notificações personalizadas",
  "Suporte prioritário",
];

export default function Pricing() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const createCheckoutMutation = trpc.subscription.createCheckoutSession.useMutation();

  const handleUpgrade = async () => {
    if (!user) {
      toast.error("Faça login para assinar o plano Premium");
      return;
    }

    setLoading(true);
    try {
      const { url } = await createCheckoutMutation.mutateAsync();
      if (url) {
        toast.success("Redirecionando para o checkout...");
        window.open(url, "_blank");
      }
    } catch (error) {
      toast.error("Erro ao criar sessão de checkout");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const isPremium = user?.subscriptionPlan === "premium";

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-primary/10 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Escolha seu Plano
          </h1>
          <p className="text-muted-foreground text-lg">
            Comece grátis ou desbloqueie todo o potencial do NutriAI
          </p>
        </div>

        {/* Plans Grid */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Free Plan */}
          <Card className="p-8 border-2 hover:shadow-lg transition-all duration-300">
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="h-6 w-6 text-muted-foreground" />
                <h2 className="text-2xl font-bold">Grátis</h2>
              </div>
              <div className="flex items-baseline gap-2 mb-4">
                <span className="text-4xl font-bold">R$ 0</span>
                <span className="text-muted-foreground">/mês</span>
              </div>
              <p className="text-muted-foreground">
                Perfeito para começar sua jornada de saúde
              </p>
            </div>

            <ul className="space-y-3 mb-8">
              {FREE_FEATURES.map((feature, index) => (
                <li key={index} className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-sm">{feature}</span>
                </li>
              ))}
            </ul>

            <Button 
              variant="outline" 
              className="w-full" 
              disabled={!isPremium}
            >
              {isPremium ? "Plano Atual" : "Plano Grátis"}
            </Button>
          </Card>

          {/* Premium Plan */}
          <Card className="p-8 border-2 border-primary hover:shadow-xl transition-all duration-300 relative overflow-hidden">
            {/* Premium Badge */}
            <div className="absolute top-4 right-4">
              <div className="bg-gradient-to-r from-primary to-primary/60 text-white text-xs font-bold px-3 py-1 rounded-full">
                POPULAR
              </div>
            </div>

            <div className="mb-6">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="h-6 w-6 text-primary" />
                <h2 className="text-2xl font-bold">Premium</h2>
              </div>
              <div className="flex items-baseline gap-2 mb-4">
                <span className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                  R$ 9,99
                </span>
                <span className="text-muted-foreground">/mês</span>
              </div>
              <p className="text-muted-foreground">
                Acesso completo a todas as funcionalidades
              </p>
            </div>

            <ul className="space-y-3 mb-8">
              {PREMIUM_FEATURES.map((feature, index) => (
                <li key={index} className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-sm font-medium">{feature}</span>
                </li>
              ))}
            </ul>

            <Button 
              className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg"
              onClick={handleUpgrade}
              disabled={loading || isPremium}
            >
              {loading ? (
                "Carregando..."
              ) : isPremium ? (
                "✓ Plano Ativo"
              ) : (
                "Assinar Premium"
              )}
            </Button>

            {isPremium && (
              <p className="text-xs text-center text-muted-foreground mt-4">
                Você já é Premium! 🎉
              </p>
            )}
          </Card>
        </div>

        {/* FAQ or Additional Info */}
        <div className="mt-16 text-center">
          <p className="text-sm text-muted-foreground">
            Todos os planos incluem atualizações gratuitas. Cancele a qualquer momento.
          </p>
        </div>
      </div>
    </div>
  );
}
