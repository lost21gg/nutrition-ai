import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useState, useEffect } from "react";
import { Bell, AlertCircle, Droplets, Zap, Award } from "lucide-react";

export default function NotificationSettings() {
  const { user, isAuthenticated } = useAuth();
  const [isSaving, setIsSaving] = useState(false);

  const { data: preferences } = trpc.notificationPreferences.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const updatePreferencesMutation = trpc.notificationPreferences.update.useMutation({
    onSuccess: () => {
      toast.success("Preferências de notificação atualizadas!");
      setIsSaving(false);
    },
    onError: () => {
      toast.error("Erro ao atualizar preferências");
      setIsSaving(false);
    },
  });

  const [settings, setSettings] = useState({
    enableCalorieAlerts: true,
    enableWaterReminders: true,
    enableMacroAlerts: true,
    enableWeightMilestones: true,
    calorieAlertThreshold: 100,
    waterReminderInterval: 120,
    notificationSound: true,
  });

  useEffect(() => {
    if (preferences) {
      setSettings({
        enableCalorieAlerts: preferences.enableCalorieAlerts ?? true,
        enableWaterReminders: preferences.enableWaterReminders ?? true,
        enableMacroAlerts: preferences.enableMacroAlerts ?? true,
        enableWeightMilestones: preferences.enableWeightMilestones ?? true,
        calorieAlertThreshold: preferences.calorieAlertThreshold ?? 100,
        waterReminderInterval: preferences.waterReminderInterval ?? 120,
        notificationSound: preferences.notificationSound ?? true,
      });
    }
  }, [preferences]);

  const handleToggle = (key: keyof typeof settings) => {
    setSettings((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleInputChange = (key: keyof typeof settings, value: number) => {
    setSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleSave = () => {
    setIsSaving(true);
    updatePreferencesMutation.mutate(settings);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Você precisa estar autenticado para acessar as configurações.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Bell className="w-6 h-6 text-primary" />
            </div>
            <h1 className="text-2xl font-bold">Configurações de Notificações</h1>
          </div>
        </div>
      </header>

      <main className="container py-8">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Alertas de Calorias */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-500" />
                Alertas de Calorias
              </CardTitle>
              <CardDescription>
                Receba notificações quando se aproximar ou ultrapassar sua meta diária
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="calorie-alerts">Ativar alertas de calorias</Label>
                <Switch
                  id="calorie-alerts"
                  checked={settings.enableCalorieAlerts}
                  onCheckedChange={() => handleToggle("enableCalorieAlerts")}
                />
              </div>
              {settings.enableCalorieAlerts && (
                <div className="space-y-2">
                  <Label htmlFor="calorie-threshold">
                    Limiar de alerta (% da meta): {settings.calorieAlertThreshold}%
                  </Label>
                  <Input
                    id="calorie-threshold"
                    type="range"
                    min="50"
                    max="150"
                    step="10"
                    value={settings.calorieAlertThreshold}
                    onChange={(e) =>
                      handleInputChange("calorieAlertThreshold", parseInt(e.target.value))
                    }
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Lembretes de Água */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Droplets className="w-5 h-5 text-blue-500" />
                Lembretes de Hidratação
              </CardTitle>
              <CardDescription>
                Receba lembretes para beber água regularmente
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="water-reminders">Ativar lembretes de água</Label>
                <Switch
                  id="water-reminders"
                  checked={settings.enableWaterReminders}
                  onCheckedChange={() => handleToggle("enableWaterReminders")}
                />
              </div>
              {settings.enableWaterReminders && (
                <div className="space-y-2">
                  <Label htmlFor="water-interval">
                    Intervalo de lembretes (minutos): {settings.waterReminderInterval}
                  </Label>
                  <Input
                    id="water-interval"
                    type="range"
                    min="30"
                    max="240"
                    step="30"
                    value={settings.waterReminderInterval}
                    onChange={(e) =>
                      handleInputChange("waterReminderInterval", parseInt(e.target.value))
                    }
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Alertas de Macronutrientes */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-green-500" />
                Alertas de Macronutrientes
              </CardTitle>
              <CardDescription>
                Notificações sobre proteínas, carboidratos e gorduras
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Label htmlFor="macro-alerts">Ativar alertas de macronutrientes</Label>
                <Switch
                  id="macro-alerts"
                  checked={settings.enableMacroAlerts}
                  onCheckedChange={() => handleToggle("enableMacroAlerts")}
                />
              </div>
            </CardContent>
          </Card>

          {/* Marcos de Peso */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-purple-500" />
                Marcos de Peso
              </CardTitle>
              <CardDescription>
                Celebre seus marcos de perda ou ganho de peso
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Label htmlFor="weight-milestones">Ativar notificações de marcos</Label>
                <Switch
                  id="weight-milestones"
                  checked={settings.enableWeightMilestones}
                  onCheckedChange={() => handleToggle("enableWeightMilestones")}
                />
              </div>
            </CardContent>
          </Card>

          {/* Som de Notificação */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle>Som de Notificação</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Label htmlFor="notification-sound">Reproduzir som nas notificações</Label>
                <Switch
                  id="notification-sound"
                  checked={settings.notificationSound}
                  onCheckedChange={() => handleToggle("notificationSound")}
                />
              </div>
            </CardContent>
          </Card>

          {/* Botão Salvar */}
          <div className="flex gap-3">
            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="flex-1"
            >
              {isSaving ? "Salvando..." : "Salvar Preferências"}
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
