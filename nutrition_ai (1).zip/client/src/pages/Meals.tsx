import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Flame, Search, Plus, Minus, ChevronLeft } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { AppLayout } from "@/components/AppLayout";

export default function Meals() {
  const [, setLocation] = useLocation();
  const [mealType, setMealType] = useState<"breakfast" | "lunch" | "dinner" | "snack" | "other">("breakfast");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFoods, setSelectedFoods] = useState<any[]>([]);

  const { data: foods } = trpc.foods.search.useQuery({ query: searchQuery, limit: 20 }, { enabled: searchQuery.length > 0 });
  const { data: allFoods } = trpc.foods.getAll.useQuery({ limit: 100 });

  const createMealMutation = trpc.meals.create.useMutation();

  const handleAddFood = (food: any) => {
    setSelectedFoods([...selectedFoods, { ...food, quantity: 100 }]);
    setSearchQuery("");
  };

  const handleRemoveFood = (index: number) => {
    setSelectedFoods(selectedFoods.filter((_, i) => i !== index));
  };

  const handleQuantityChange = (index: number, quantity: number) => {
    const updated = [...selectedFoods];
    updated[index].quantity = quantity;
    setSelectedFoods(updated);
  };

  const handleSaveMeal = async () => {
    if (selectedFoods.length === 0) {
      toast.error("Adicione pelo menos um alimento");
      return;
    }
    const today = new Date().toISOString().split('T')[0];
    try {
      await createMealMutation.mutateAsync({
        mealType,
        date: today,
        notes: `Refeição com ${selectedFoods.length} itens`,
        totalCalories: Math.round(totalCalories),
        totalProtein: Math.round(totalProtein),
        totalCarbs: Math.round(totalCarbs),
        totalFat: Math.round(totalFat),
      });
      toast.success("Refeição salva com sucesso!");
      setSelectedFoods([]);
      setLocation("/dashboard");
    } catch (error) {
      toast.error("Erro ao salvar refeição");
    }
  };

  const totalCalories = selectedFoods.reduce((sum, food) => sum + ((food.calories || 0) * food.quantity / 100), 0);
  const totalProtein = selectedFoods.reduce((sum, food) => sum + ((food.protein || 0) * food.quantity / 100), 0);
  const totalCarbs = selectedFoods.reduce((sum, food) => sum + ((food.carbs || 0) * food.quantity / 100), 0);
  const totalFat = selectedFoods.reduce((sum, food) => sum + ((food.fat || 0) * food.quantity / 100), 0);

  return (
    <AppLayout>
      <div className="bg-background min-h-full">
        {/* Header */}
        <div className="sticky top-0 bg-card border-b border-border z-10 px-4 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => setLocation("/dashboard")}>
              <ChevronLeft className="w-6 h-6" />
            </Button>
            <div className="flex-1">
              <h1 className="text-lg font-semibold">Adicionar Refeição</h1>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Meal Type Selector */}
          <Card>
            <CardContent className="pt-4">
              <Select value={mealType} onValueChange={(value: any) => setMealType(value)}>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Tipo de refeição" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="breakfast">Café da Manhã</SelectItem>
                  <SelectItem value="lunch">Almoço</SelectItem>
                  <SelectItem value="dinner">Jantar</SelectItem>
                  <SelectItem value="snack">Lanche</SelectItem>
                  <SelectItem value="other">Outro</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Buscar alimento..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 text-base"
            />
          </div>

          {/* Search Results */}
          {searchQuery.length > 0 && foods && foods.length > 0 && (
            <Card>
              <CardContent className="p-2">
                <div className="space-y-1 max-h-64 overflow-y-auto">
                  {foods.map((food) => (
                    <button
                      key={food.id}
                      onClick={() => handleAddFood(food)}
                      className="w-full flex items-center justify-between p-3 hover:bg-accent rounded-lg transition-colors text-left"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{food.name}</p>
                        <p className="text-xs text-muted-foreground">{food.calories} kcal / 100g</p>
                      </div>
                      <Plus className="w-5 h-5 text-primary flex-shrink-0 ml-2" />
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Selected Foods */}
          {selectedFoods.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Alimentos Adicionados</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {selectedFoods.map((food, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-accent/50 rounded-lg">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{food.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {Math.round((food.calories || 0) * food.quantity / 100)} kcal
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        value={food.quantity}
                        onChange={(e) => handleQuantityChange(index, parseInt(e.target.value) || 0)}
                        className="w-16 h-8 text-center text-sm"
                      />
                      <span className="text-xs text-muted-foreground">g</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveFood(index)}
                        className="h-8 w-8 flex-shrink-0"
                      >
                        <Minus className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Summary */}
          {selectedFoods.length > 0 && (
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="pt-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">Total</span>
                    <span className="text-2xl font-bold">{Math.round(totalCalories)} kcal</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="text-center p-2 bg-background/50 rounded">
                      <p className="text-muted-foreground">Proteínas</p>
                      <p className="font-semibold">{Math.round(totalProtein)}g</p>
                    </div>
                    <div className="text-center p-2 bg-background/50 rounded">
                      <p className="text-muted-foreground">Carboidratos</p>
                      <p className="font-semibold">{Math.round(totalCarbs)}g</p>
                    </div>
                    <div className="text-center p-2 bg-background/50 rounded">
                      <p className="text-muted-foreground">Gorduras</p>
                      <p className="font-semibold">{Math.round(totalFat)}g</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Save Button */}
          {selectedFoods.length > 0 && (
            <Button
              onClick={handleSaveMeal}
              disabled={createMealMutation.isPending}
              className="w-full h-12 text-base font-semibold"
              size="lg"
            >
              {createMealMutation.isPending ? "Salvando..." : "Salvar Refeição"}
            </Button>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
