import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Flame, Droplets, Activity, Camera, Plus, TrendingUp } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { AppLayout } from "@/components/AppLayout";
import { UpgradeModal } from "@/components/UpgradeModal";

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [todayCalories, setTodayCalories] = useState(0);
  const [todayProtein, setTodayProtein] = useState(0);
  const [todayCarbs, setTodayCarbs] = useState(0);
  const [todayFat, setTodayFat] = useState(0);
  const [caloriesBurned, setCaloriesBurned] = useState(0);
  const [mealCount, setMealCount] = useState(0);
  const [exerciseCount, setExerciseCount] = useState(0);
  const [isAddingExercise, setIsAddingExercise] = useState(false);
  const [exerciseForm, setExerciseForm] = useState({
    exerciseId: "",
    duration: "",
  });
  const [waterIntake, setWaterIntake] = useState(0);
  const [isAddingWater, setIsAddingWater] = useState(false);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [upgradeFeature, setUpgradeFeature] = useState("");

  const today = new Date().toISOString().split("T")[0];

  // Fetch meals for today
  const { data: mealsData, refetch: refetchMeals } = trpc.meals.getForDay.useQuery(
    { date: today },
    { enabled: isAuthenticated }
  );

  // Fetch exercises for today
  const { data: exercisesData, refetch: refetchExercises } = trpc.exercises.getForDay.useQuery(
    { date: today },
    { enabled: isAuthenticated }
  );

  // Fetch all exercises for dropdown
  const { data: allExercises } = trpc.exercises.getAll.useQuery(
    { limit: 50 },
    { enabled: isAuthenticated }
  );

  // Fetch water intake for today
  const { data: waterData, refetch: refetchWater } = trpc.water.getTotalForDay.useQuery(
    { date: today },
    { enabled: isAuthenticated }
  );

  const utils = trpc.useUtils();

  const addWaterMutation = trpc.water.add.useMutation({
    onSuccess: async () => {
      toast.success("Água adicionada!");
      setIsAddingWater(false);
      // Invalidate and refetch
      await utils.water.getTotalForDay.invalidate({ date: today });
      refetchWater();
    },
    onError: () => {
      toast.error("Erro ao adicionar água");
    },
  });

  const addExerciseMutation = trpc.exercises.add.useMutation({
    onSuccess: () => {
      toast.success("Exercício adicionado!");
      setExerciseForm({ exerciseId: "", duration: "" });
      setIsAddingExercise(false);
      refetchExercises();
    },
    onError: () => {
      toast.error("Erro ao adicionar exercício");
    },
  });

  // Update calories when meals change
  useEffect(() => {
    let isMounted = true;
    if (mealsData && isMounted) {
      const totalCalories = mealsData.reduce((sum: number, meal: any) => sum + (meal.totalCalories || 0), 0);
      const totalProtein = mealsData.reduce((sum: number, meal: any) => sum + (meal.totalProtein || 0), 0);
      const totalCarbs = mealsData.reduce((sum: number, meal: any) => sum + (meal.totalCarbs || 0), 0);
      const totalFat = mealsData.reduce((sum: number, meal: any) => sum + (meal.totalFat || 0), 0);

      setTodayCalories(totalCalories);
      setTodayProtein(totalProtein);
      setTodayCarbs(totalCarbs);
      setTodayFat(totalFat);
      setMealCount(mealsData.length);
    }
    return () => {
      isMounted = false;
    };
  }, [mealsData]);

  // Update exercises when data changes
  useEffect(() => {
    let isMounted = true;
    if (exercisesData && isMounted) {
      const totalBurned = exercisesData.reduce((sum: number, ex: any) => sum + (ex.caloriesBurned || 0), 0);
      setCaloriesBurned(totalBurned);
      setExerciseCount(exercisesData.length);
    }
    return () => {
      isMounted = false;
    };
  }, [exercisesData]);

  // Update water when data changes
  useEffect(() => {
    let isMounted = true;
    if (waterData !== undefined && isMounted) {
      setWaterIntake(waterData);
    }
    return () => {
      isMounted = false;
    };
  }, [waterData]);

  const handleAddWater = (amount: number) => {
    addWaterMutation.mutate({
      amount,
      date: today,
    });
  };

  const handleAddExercise = () => {
    if (!exerciseForm.exerciseId || !exerciseForm.duration) {
      toast.error("Preencha todos os campos");
      return;
    }

    addExerciseMutation.mutate({
      exerciseId: parseInt(exerciseForm.exerciseId),
      date: today,
      duration: parseInt(exerciseForm.duration),
      notes: "",
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card>
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Você precisa estar autenticado para acessar o dashboard.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const netCalories = todayCalories - caloriesBurned;
  const caloriePercentage = Math.min((netCalories / 2000) * 100, 100);

  return (
    <AppLayout>
      <div className="bg-background min-h-full pb-6">
        {/* Header with gradient */}
        <div className="bg-gradient-to-br from-primary/10 via-primary/5 to-background px-4 pt-6 pb-8 rounded-b-3xl shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Olá, {user?.name?.split(" ")[0] || "Usuário"}!</h1>
              <p className="text-sm text-muted-foreground mt-0.5">
                {new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" })}
              </p>
            </div>
          </div>

          {/* Calorie Ring Card - Elevated */}
          <Card className="bg-card/95 backdrop-blur-sm border-border/50 shadow-lg">
            <CardContent className="pt-6 pb-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground mb-2">Calorias Líquidas</p>
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-5xl font-bold bg-gradient-to-br from-foreground to-foreground/70 bg-clip-text text-transparent">
                      {netCalories}
                    </span>
                    <span className="text-lg text-muted-foreground">kcal</span>
                  </div>
                  <div className="flex flex-col gap-2 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-gradient-to-br from-orange-500 to-red-500"></div>
                      <span className="text-muted-foreground">Consumidas:</span>
                      <span className="font-semibold text-orange-600">{todayCalories}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-gradient-to-br from-green-500 to-emerald-500"></div>
                      <span className="text-muted-foreground">Queimadas:</span>
                      <span className="font-semibold text-green-600">{caloriesBurned}</span>
                    </div>
                  </div>
                </div>
                <div className="relative w-28 h-28 flex-shrink-0">
                  <svg className="w-28 h-28 transform -rotate-90">
                    <defs>
                      <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="hsl(var(--primary))" />
                        <stop offset="100%" stopColor="hsl(var(--primary) / 0.6)" />
                      </linearGradient>
                    </defs>
                    <circle
                      cx="56"
                      cy="56"
                      r="48"
                      stroke="currentColor"
                      strokeWidth="10"
                      fill="none"
                      className="text-muted/10"
                    />
                    <circle
                      cx="56"
                      cy="56"
                      r="48"
                      stroke="url(#progressGradient)"
                      strokeWidth="10"
                      fill="none"
                      strokeDasharray={`${(caloriePercentage / 100) * 301.6} 301.6`}
                      className="transition-all duration-700 ease-out"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                      <Flame className="w-8 h-8 text-primary" />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="px-4 space-y-5 -mt-2">
          {/* Quick Stats with gradient backgrounds */}
          <div className="grid grid-cols-3 gap-3">
            <Card className="border-border/50 bg-gradient-to-br from-orange-500/5 to-background hover:shadow-md transition-shadow">
              <CardContent className="pt-5 pb-5 px-3">
                <div className="flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-500/20 to-red-500/20 flex items-center justify-center mb-3 shadow-sm">
                    <Flame className="w-6 h-6 text-orange-500" />
                  </div>
                  <p className="text-2xl font-bold text-foreground">{mealCount}</p>
                  <p className="text-xs text-muted-foreground mt-1">Refeições</p>
                </div>
              </CardContent>
            </Card>

            <Card 
              className="border-border/50 bg-gradient-to-br from-blue-500/5 to-background hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => {
                if (user?.subscriptionPlan !== "premium") {
                  setUpgradeFeature("Controle de água");
                  setShowUpgradeModal(true);
                } else {
                  setIsAddingWater(true);
                }
              }}
            >
              <CardContent className="pt-5 pb-5 px-3">
                <div className="flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center mb-3 shadow-sm">
                    <Droplets className="w-6 h-6 text-blue-500" />
                  </div>
                  <p className="text-2xl font-bold text-foreground">{(waterIntake / 1000).toFixed(1)}L</p>
                  <p className="text-xs text-muted-foreground mt-1">Água</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/50 bg-gradient-to-br from-purple-500/5 to-background hover:shadow-md transition-shadow">
              <CardContent className="pt-5 pb-5 px-3">
                <div className="flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center mb-3 shadow-sm">
                    <Activity className="w-6 h-6 text-purple-500" />
                  </div>
                  <p className="text-2xl font-bold text-foreground">{exerciseCount}</p>
                  <p className="text-xs text-muted-foreground mt-1">Exercícios</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Macros with improved design */}
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-base font-semibold">Macronutrientes Hoje</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">Proteínas</span>
                  <span className="text-sm font-bold text-red-600">{todayProtein}g</span>
                </div>
                <div className="w-full bg-muted/50 rounded-full h-2.5 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-red-500 to-red-600 h-2.5 rounded-full transition-all duration-500 ease-out shadow-sm" 
                    style={{ width: `${Math.min((todayProtein / 150) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">Carboidratos</span>
                  <span className="text-sm font-bold text-blue-600">{todayCarbs}g</span>
                </div>
                <div className="w-full bg-muted/50 rounded-full h-2.5 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out shadow-sm" 
                    style={{ width: `${Math.min((todayCarbs / 250) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">Gorduras</span>
                  <span className="text-sm font-bold text-yellow-600">{todayFat}g</span>
                </div>
                <div className="w-full bg-muted/50 rounded-full h-2.5 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-yellow-500 to-yellow-600 h-2.5 rounded-full transition-all duration-500 ease-out shadow-sm" 
                    style={{ width: `${Math.min((todayFat / 65) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions with improved styling */}
          <div className="space-y-3">
            <Button
              onClick={() => setLocation("/meals/photo")}
              className="w-full h-14 text-base font-semibold bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary/80 shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all"
              size="lg"
            >
              <Camera className="w-5 h-5 mr-2" />
              Tirar Foto do Prato
            </Button>

            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={() => setLocation("/meals/new")}
                variant="outline"
                className="h-14 border-border/50 hover:bg-primary/5 hover:border-primary/30 transition-all"
              >
                <Plus className="w-5 h-5 mr-2" />
                Adicionar Refeição
              </Button>

              <Dialog open={isAddingExercise} onOpenChange={setIsAddingExercise}>
                <DialogTrigger asChild>
                  <Button
                    variant="outline"
                    className="h-14 border-border/50 hover:bg-primary/5 hover:border-primary/30 transition-all"
                    onClick={(e) => {
                      if (user?.subscriptionPlan !== "premium") {
                        e.preventDefault();
                        setUpgradeFeature("Sistema de exercícios");
                        setShowUpgradeModal(true);
                      }
                    }}
                  >
                    <TrendingUp className="w-5 h-5 mr-2" />
                    Adicionar Exercício
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Adicionar Exercício</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="exercise">Exercício</Label>
                      <Select
                        value={exerciseForm.exerciseId}
                        onValueChange={(value) => setExerciseForm({ ...exerciseForm, exerciseId: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione um exercício" />
                        </SelectTrigger>
                        <SelectContent>
                          {allExercises?.map((exercise: any) => (
                            <SelectItem key={exercise.id} value={exercise.id.toString()}>
                              {exercise.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="duration">Duração (minutos)</Label>
                      <Input
                        id="duration"
                        type="number"
                        placeholder="30"
                        value={exerciseForm.duration}
                        onChange={(e) => setExerciseForm({ ...exerciseForm, duration: e.target.value })}
                      />
                    </div>
                    <Button onClick={handleAddExercise} className="w-full">
                      Adicionar
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>

        {/* Water Dialog */}
        <Dialog open={isAddingWater} onOpenChange={setIsAddingWater}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Água</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <p className="text-sm text-muted-foreground">Selecione a quantidade de água consumida:</p>
              <div className="grid grid-cols-3 gap-3">
                <Button
                  onClick={() => handleAddWater(250)}
                  variant="outline"
                  className="h-20 flex flex-col items-center justify-center"
                >
                  <Droplets className="w-6 h-6 mb-1 text-blue-500" />
                  <span className="text-lg font-bold">250ml</span>
                </Button>
                <Button
                  onClick={() => handleAddWater(500)}
                  variant="outline"
                  className="h-20 flex flex-col items-center justify-center"
                >
                  <Droplets className="w-6 h-6 mb-1 text-blue-500" />
                  <span className="text-lg font-bold">500ml</span>
                </Button>
                <Button
                  onClick={() => handleAddWater(1000)}
                  variant="outline"
                  className="h-20 flex flex-col items-center justify-center"
                >
                  <Droplets className="w-6 h-6 mb-1 text-blue-500" />
                  <span className="text-lg font-bold">1L</span>
                </Button>
              </div>
              <div className="pt-2">
                <p className="text-sm text-center text-muted-foreground">
                  Total hoje: <span className="font-bold text-foreground">{(waterIntake / 1000).toFixed(1)}L</span>
                </p>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <UpgradeModal 
        open={showUpgradeModal} 
        onClose={() => setShowUpgradeModal(false)} 
        feature={upgradeFeature}
      />
    </AppLayout>
  );
}
