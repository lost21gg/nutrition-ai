import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useState, useEffect } from "react";
import { User, LogOut, Moon, Sun, Sparkles, Crown } from "lucide-react";
import { useLocation } from "wouter";
import { AppLayout } from "@/components/AppLayout";
import { getLoginUrl } from "@/const";
import { useTheme } from "@/contexts/ThemeContext";

export default function Profile() {
  const { user, isAuthenticated, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [, setLocation] = useLocation();
  const [isSaving, setIsSaving] = useState(false);

  const { data: profile } = trpc.profile.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const updateProfileMutation = trpc.profile.update.useMutation({
    onSuccess: () => {
      toast.success("Perfil atualizado!");
      setIsSaving(false);
    },
    onError: () => {
      toast.error("Erro ao atualizar perfil");
      setIsSaving(false);
    },
  });

  const logoutMutation = trpc.auth.logout.useMutation();

  const [profileData, setProfileData] = useState({
    weight: 0,
    height: 0,
    age: 0,
    gender: "male" as "male" | "female" | "other",
    objective: "maintain" as "lose" | "maintain" | "gain",
    dietType: "normal" as "normal" | "vegan" | "vegetarian" | "lowcarb" | "keto" | "highprotein",
    dailyCalorieGoal: 2000,
    allergies: "",
    preferences: "",
  });

  useEffect(() => {
    if (profile) {
      setProfileData({
        weight: profile.weight || 0,
        height: profile.height || 0,
        age: profile.age || 0,
        gender: profile.gender || "male",
        objective: profile.objective || "maintain",
        dietType: profile.dietType || "normal",
        dailyCalorieGoal: profile.dailyCalorieGoal || 2000,
        allergies: profile.allergies || "",
        preferences: profile.preferences || "",
      });
    }
  }, [profile]);

  const handleSave = () => {
    setIsSaving(true);
    updateProfileMutation.mutate(profileData);
  };

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      logout();
      window.location.href = "/";
    } catch (error) {
      toast.error("Erro ao fazer logout");
    }
  };

  if (!isAuthenticated) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center min-h-full p-4">
          <Card>
            <CardHeader>
              <CardTitle>Acesso Negado</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Você precisa estar autenticado para acessar o perfil.</p>
              <Button onClick={() => window.location.href = getLoginUrl()} className="w-full">
                Fazer Login
              </Button>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="bg-background min-h-full">
        {/* Header */}
        <div className="bg-gradient-to-br from-primary/10 to-primary/5 px-4 pt-6 pb-8">
          <div className="flex flex-col items-center">
            <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center mb-3">
              <User className="w-10 h-10 text-primary" />
            </div>
            <h1 className="text-xl font-bold">{user?.name}</h1>
            <p className="text-sm text-muted-foreground">{user?.email}</p>
            {user?.subscriptionPlan === "premium" ? (
              <div className="mt-2 flex items-center gap-1 bg-gradient-to-r from-primary to-primary/60 text-white px-3 py-1 rounded-full text-xs font-bold">
                <Crown className="w-3 h-3" />
                Premium
              </div>
            ) : (
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-2 text-xs h-7"
                onClick={() => setLocation("/pricing")}
              >
                <Sparkles className="w-3 h-3 mr-1" />
                Assinar Premium
              </Button>
            )}
          </div>
        </div>

        <div className="p-4 space-y-4 -mt-4">
          {/* Personal Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Informações Pessoais</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="weight" className="text-sm">Peso (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    value={profileData.weight || ""}
                    onChange={(e) => setProfileData({ ...profileData, weight: parseFloat(e.target.value) || 0 })}
                    className="h-10"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="height" className="text-sm">Altura (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    value={profileData.height || ""}
                    onChange={(e) => setProfileData({ ...profileData, height: parseFloat(e.target.value) || 0 })}
                    className="h-10"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="age" className="text-sm">Idade</Label>
                  <Input
                    id="age"
                    type="number"
                    value={profileData.age || ""}
                    onChange={(e) => setProfileData({ ...profileData, age: parseInt(e.target.value) || 0 })}
                    className="h-10"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender" className="text-sm">Gênero</Label>
                  <Select value={profileData.gender} onValueChange={(value: any) => setProfileData({ ...profileData, gender: value })}>
                    <SelectTrigger className="h-10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Masculino</SelectItem>
                      <SelectItem value="female">Feminino</SelectItem>
                      <SelectItem value="other">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Goals */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Objetivos</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="objective" className="text-sm">Objetivo</Label>
                <Select value={profileData.objective} onValueChange={(value: any) => setProfileData({ ...profileData, objective: value })}>
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lose">Perder Peso</SelectItem>
                    <SelectItem value="maintain">Manter Peso</SelectItem>
                    <SelectItem value="gain">Ganhar Massa</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="dietType" className="text-sm">Tipo de Dieta</Label>
                <Select value={profileData.dietType} onValueChange={(value: any) => setProfileData({ ...profileData, dietType: value })}>
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="vegan">Vegana</SelectItem>
                    <SelectItem value="vegetarian">Vegetariana</SelectItem>
                    <SelectItem value="lowcarb">Low Carb</SelectItem>
                    <SelectItem value="keto">Keto</SelectItem>
                    <SelectItem value="highprotein">High Protein</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="dailyCalorieGoal" className="text-sm">Meta Diária de Calorias</Label>
                <Input
                  id="dailyCalorieGoal"
                  type="number"
                  value={profileData.dailyCalorieGoal || ""}
                  onChange={(e) => setProfileData({ ...profileData, dailyCalorieGoal: parseInt(e.target.value) || 0 })}
                  className="h-10"
                />
              </div>
            </CardContent>
          </Card>

          {/* Preferences */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Preferências e Restrições</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="allergies" className="text-sm">Alergias</Label>
                <Input
                  id="allergies"
                  placeholder="Ex: Amendoim, Lactose"
                  value={profileData.allergies}
                  onChange={(e) => setProfileData({ ...profileData, allergies: e.target.value })}
                  className="h-10"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="preferences" className="text-sm">Preferências Alimentares</Label>
                <Input
                  id="preferences"
                  placeholder="Ex: Prefiro comidas leves"
                  value={profileData.preferences}
                  onChange={(e) => setProfileData({ ...profileData, preferences: e.target.value })}
                  className="h-10"
                />
              </div>
            </CardContent>
          </Card>

          {/* Theme Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Aparência</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {theme === 'dark' ? (
                    <Moon className="w-5 h-5 text-primary" />
                  ) : (
                    <Sun className="w-5 h-5 text-primary" />
                  )}
                  <div>
                    <p className="font-medium text-sm">Tema {theme === 'dark' ? 'Escuro' : 'Claro'}</p>
                    <p className="text-xs text-muted-foreground">Alterne entre claro e escuro</p>
                  </div>
                </div>
                <Button
                  onClick={toggleTheme}
                  variant="outline"
                  size="sm"
                  className="h-9"
                >
                  {theme === 'dark' ? 'Claro' : 'Escuro'}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="space-y-3">
            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="w-full h-12 text-base font-semibold"
            >
              {isSaving ? "Salvando..." : "Salvar Alterações"}
            </Button>

            <Button
              onClick={handleLogout}
              variant="outline"
              className="w-full h-12 text-base"
            >
              <LogOut className="w-5 h-5 mr-2" />
              Sair da Conta
            </Button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
