import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calculator, Activity } from "lucide-react";
import { AppLayout } from "@/components/AppLayout";

export default function Calculators() {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("male");
  const [activityLevel, setActivityLevel] = useState("sedentary");
  const [targetWeight, setTargetWeight] = useState("");

  const [results, setResults] = useState({
    imc: 0,
    mmc: 0,
    tmb: 0,
    tdee: 0,
  });

  const calculateAll = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height) / 100; // convert to meters
    const a = parseFloat(age);
    const tw = parseFloat(targetWeight);

    if (!w || !h || !a) return;

    // IMC
    const imc = w / (h * h);

    // MMC (Meta de Massa Corporal)
    const mmc = tw ? tw / (h * h) : 0;

    // TMB (Taxa Metabólica Basal) - Harris-Benedict
    let tmb = 0;
    if (gender === "male") {
      tmb = 88.362 + (13.397 * w) + (4.799 * (h * 100)) - (5.677 * a);
    } else {
      tmb = 447.593 + (9.247 * w) + (3.098 * (h * 100)) - (4.330 * a);
    }

    // TDEE (Gasto Calórico Total Diário)
    const activityMultipliers: Record<string, number> = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      veryActive: 1.9,
    };
    const tdee = tmb * activityMultipliers[activityLevel];

    setResults({ imc, mmc, tmb, tdee });
  };

  const getIMCCategory = (imc: number) => {
    if (imc < 18.5) return { text: "Abaixo do peso", color: "text-blue-500" };
    if (imc < 25) return { text: "Peso normal", color: "text-green-500" };
    if (imc < 30) return { text: "Sobrepeso", color: "text-yellow-500" };
    return { text: "Obesidade", color: "text-red-500" };
  };

  const imcCategory = results.imc > 0 ? getIMCCategory(results.imc) : null;

  return (
    <AppLayout>
      <div className="bg-background min-h-full">
        {/* Header */}
        <div className="bg-gradient-to-br from-primary/10 to-primary/5 px-4 pt-6 pb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
              <Calculator className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Calculadoras</h1>
              <p className="text-sm text-muted-foreground">IMC, TMB, TDEE e mais</p>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Input Form */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Suas Informações</CardTitle>
              <CardDescription className="text-xs">Preencha os dados para calcular</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="weight" className="text-sm">Peso (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="70"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    className="h-10"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="height" className="text-sm">Altura (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="170"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    className="h-10"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="age" className="text-sm">Idade</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="30"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="h-10"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender" className="text-sm">Gênero</Label>
                  <Select value={gender} onValueChange={setGender}>
                    <SelectTrigger className="h-10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Masculino</SelectItem>
                      <SelectItem value="female">Feminino</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="activity" className="text-sm">Nível de Atividade</Label>
                <Select value={activityLevel} onValueChange={setActivityLevel}>
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sedentary">Sedentário</SelectItem>
                    <SelectItem value="light">Leve (1-3x/semana)</SelectItem>
                    <SelectItem value="moderate">Moderado (3-5x/semana)</SelectItem>
                    <SelectItem value="active">Ativo (6-7x/semana)</SelectItem>
                    <SelectItem value="veryActive">Muito Ativo (2x/dia)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="targetWeight" className="text-sm">Peso Alvo (opcional)</Label>
                <Input
                  id="targetWeight"
                  type="number"
                  placeholder="65"
                  value={targetWeight}
                  onChange={(e) => setTargetWeight(e.target.value)}
                  className="h-10"
                />
              </div>

              <Button onClick={calculateAll} className="w-full h-11 text-base font-semibold">
                <Calculator className="w-5 h-5 mr-2" />
                Calcular
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          {results.imc > 0 && (
            <>
              {/* IMC */}
              <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-background">
                <CardContent className="pt-5 pb-5">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">IMC</p>
                      <p className="text-3xl font-bold">{results.imc.toFixed(1)}</p>
                      {imcCategory && (
                        <p className={`text-sm font-medium mt-1 ${imcCategory.color}`}>
                          {imcCategory.text}
                        </p>
                      )}
                    </div>
                    <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                      <Activity className="w-8 h-8 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Other Metrics */}
              <div className="grid grid-cols-2 gap-3">
                <Card>
                  <CardContent className="pt-4 pb-4">
                    <p className="text-xs text-muted-foreground mb-1">TMB</p>
                    <p className="text-2xl font-bold">{Math.round(results.tmb)}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">kcal/dia</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-4 pb-4">
                    <p className="text-xs text-muted-foreground mb-1">TDEE</p>
                    <p className="text-2xl font-bold">{Math.round(results.tdee)}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">kcal/dia</p>
                  </CardContent>
                </Card>
              </div>

              {results.mmc > 0 && (
                <Card>
                  <CardContent className="pt-4 pb-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Meta de IMC</p>
                        <p className="text-2xl font-bold">{results.mmc.toFixed(1)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">Peso Alvo</p>
                        <p className="text-lg font-semibold">{targetWeight} kg</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Info Card */}
              <Card className="bg-muted/50">
                <CardContent className="pt-4 pb-4">
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    <strong>TMB</strong> é a energia que seu corpo gasta em repouso. <strong>TDEE</strong> é o gasto total considerando suas atividades diárias.
                  </p>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
