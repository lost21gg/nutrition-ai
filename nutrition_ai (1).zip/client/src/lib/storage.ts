/**
 * Storage helper for uploading files to S3
 * This is a client-side wrapper that calls the backend storage API
 */

export async function storagePut(
  key: string,
  data: File | Blob | string,
  contentType?: string
): Promise<{ url: string; key: string }> {
  // Convert data to FormData for multipart upload
  const formData = new FormData();
  formData.append("key", key);
  formData.append("file", data);
  if (contentType) {
    formData.append("contentType", contentType);
  }

  // Call backend endpoint to upload
  const response = await fetch("/api/storage/upload", {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    throw new Error("Failed to upload file");
  }

  return response.json();
}

export async function storageGet(
  key: string,
  expiresIn?: number
): Promise<{ url: string; key: string }> {
  const params = new URLSearchParams({ key });
  if (expiresIn) {
    params.append("expiresIn", expiresIn.toString());
  }

  const response = await fetch(`/api/storage/get?${params}`, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error("Failed to get file URL");
  }

  return response.json();
}
